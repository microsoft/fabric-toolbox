"""DAX Performance Tuner MCP Server version information."""

__version__ = "0.1.0"
__title__ = "DAX Performance Tuner"
__description__ = "LLM-guided DAX optimization MCP server with evidence-based methodology"
