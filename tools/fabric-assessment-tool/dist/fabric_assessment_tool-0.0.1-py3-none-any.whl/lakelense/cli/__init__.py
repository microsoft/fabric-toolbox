"""CLI module for LakeLense."""
