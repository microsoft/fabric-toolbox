# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

# Don't change this
__version__ = "0.0.1"
