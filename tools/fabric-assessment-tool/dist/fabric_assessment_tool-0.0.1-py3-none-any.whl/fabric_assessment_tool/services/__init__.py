"""Services module for Fabric Assessment Tool business logic."""
