"""Commands module for Fabric Assessment Tool CLI."""
