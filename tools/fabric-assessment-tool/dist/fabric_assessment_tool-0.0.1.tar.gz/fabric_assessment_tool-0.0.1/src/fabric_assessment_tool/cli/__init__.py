"""CLI module for Fabric Assessment Tool."""
